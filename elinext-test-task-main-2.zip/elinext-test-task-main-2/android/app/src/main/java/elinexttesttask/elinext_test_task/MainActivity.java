package elinexttesttask.elinext_test_task;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
