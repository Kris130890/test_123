# Elinext test task

API: https://newsapi.org/docs (sign up and get apiKey for further API communication).
Description:
create a simple news app with 3 pages:
1. List of news
• Image / fallback image if not specified or retrieved
• Title of the news
• Implement incremental loading functionality
2. Details page:
• Title of the news
• Description of the news
• Image / fallback image if not specified or retrieved
• Publication date
• Author
• Add to / remove from saved news button
• Button with navigation to the source news in the browser
3. saved news (UI same with ‘List of news’)
