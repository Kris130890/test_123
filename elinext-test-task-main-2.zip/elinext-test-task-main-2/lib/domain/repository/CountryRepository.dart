import 'package:elinext_test_task/domain/model/country/country.dart';

abstract class CountryRepository {
  Future<Country> loadCountryNews(int countNews);
}
