abstract class CountryFavoritesEvent {}

class OnCountryFavoritesRefresh extends CountryFavoritesEvent {}
