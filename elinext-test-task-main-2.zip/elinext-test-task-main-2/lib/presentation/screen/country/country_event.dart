abstract class CountryEvent {}

class OnCountryRefresh extends CountryEvent {}
