class AppImages {
  AppImages._();

  static const no_image_available = 'res/images/no_image_available.jpg';
}
